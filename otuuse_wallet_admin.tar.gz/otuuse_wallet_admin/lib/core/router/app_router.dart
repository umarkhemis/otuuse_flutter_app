import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/admin/screens/admin_home_screen.dart';
import '../../features/auth/data/auth_session.dart';
import '../../features/auth/providers/auth_provider.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/otp_screen.dart';
import '../../features/chat/screens/chat_screen.dart';
import '../../features/driver/screens/driver_home_screen.dart';
import 'splash_screen.dart';

class _RouterRefreshNotifier extends ChangeNotifier {
  _RouterRefreshNotifier(Ref ref) {
    ref.listen(authProvider, (_, __) => notifyListeners());
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final refreshNotifier = _RouterRefreshNotifier(ref);

  return GoRouter(
    initialLocation: '/',
    refreshListenable: refreshNotifier,
    redirect: (context, state) {
      final authState = ref.read(authProvider);
      final isAuthRoute = state.matchedLocation == '/login' ||
          state.matchedLocation == '/verify-otp';

      if (authState.status == AuthStatus.unknown) {
        return state.matchedLocation == '/' ? null : '/';
      }

      if (authState.status == AuthStatus.unauthenticated) {
        return isAuthRoute ? null : '/login';
      }

      if (authState.status == AuthStatus.authenticated) {
        final correctHome = switch (authState.session?.role) {
          UserRole.driver => '/driver/home',
          UserRole.admin => '/admin/home',
          _ => '/rides/home',
        };
        if (state.matchedLocation != correctHome) return correctHome;
      }

      return null;
    },
    routes: [
      GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/verify-otp',
        builder: (context, state) {
          final phoneNumber = state.extra as String?;
          if (phoneNumber == null) return const LoginScreen();
          return OtpScreen(phoneNumber: phoneNumber);
        },
      ),
      GoRoute(
          path: '/rides/home',
          builder: (context, state) => const ChatScreen()),
      GoRoute(
          path: '/driver/home',
          builder: (context, state) => const DriverHomeScreen()),
      GoRoute(
          path: '/admin/home',
          builder: (context, state) => const AdminHomeScreen()),
    ],
  );
});
