import 'package:dio/dio.dart';

import '../../../core/api/api_client.dart';
import '../../../core/api/api_exception.dart';
import '../../../core/storage/token_storage.dart';
import 'auth_session.dart';

class AuthRepository {
  AuthRepository(this._apiClient, this._tokenStorage);

  final ApiClient _apiClient;
  final TokenStorage _tokenStorage;

  /// Sends an OTP to [phoneNumber]. For a brand-new phone number, [name]
  /// and [role] register the account at the same time - matches the
  /// backend's request-otp endpoint, which creates the user record on
  /// first contact rather than needing a separate signup step.
  Future<void> requestOtp({
    required String phoneNumber,
    required String name,
    required String role,
  }) async {
    try {
      await _apiClient.dio.post('/auth/request-otp', data: {
        'phone_number': phoneNumber,
        'name': name,
        'role': role,
      });
    } on DioException catch (e) {
      throw ApiException.fromDioException(e);
    }
  }

  Future<AuthSession> verifyOtp({
    required String phoneNumber,
    required String otp,
  }) async {
    try {
      final response = await _apiClient.dio.post('/auth/verify-otp', data: {
        'phone_number': phoneNumber,
        'otp': otp,
      });

      final data = response.data;
      await _tokenStorage.saveTokens(
        accessToken: data['access_token'] as String,
        refreshToken: data['refresh_token'] as String,
        role: data['role'] as String,
        userId: data['user_id'] as String,
      );

      return AuthSession(userId: data['user_id'] as String, role: data['role'] as String);
    } on DioException catch (e) {
      throw ApiException.fromDioException(e);
    }
  }

  Future<void> logout() async {
    final refreshToken = await _tokenStorage.getRefreshToken();
    if (refreshToken != null) {
      try {
        await _apiClient.dio.post('/auth/logout', data: {'refresh_token': refreshToken});
      } catch (_) {
        // Best-effort - the user can still log out locally even if the
        // network call to revoke the token server-side fails (no internet,
        // backend down, etc.). Worst case the refresh token sits unused
        // until it expires on its own.
      }
    }
    await _tokenStorage.clear();
  }

  /// Checks whether there's a saved session from a previous app launch.
  /// Doesn't validate the access token against the server - that happens
  /// naturally on the first real API call, via the refresh-on-401 flow in
  /// ApiClient.
  Future<AuthSession?> restoreSession() async {
    final accessToken = await _tokenStorage.getAccessToken();
    final role = await _tokenStorage.getRole();
    final userId = await _tokenStorage.getUserId();

    if (accessToken == null || role == null || userId == null) return null;
    return AuthSession(userId: userId, role: role);
  }
}
