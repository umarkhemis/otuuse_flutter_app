/// Mirrors the backend's UserRole enum (app/models/models.py).
enum UserRole { passenger, driver, admin }

UserRole userRoleFromString(String value) {
  switch (value) {
    case 'driver':
      return UserRole.driver;
    case 'admin':
      return UserRole.admin;
    case 'passenger':
    default:
      return UserRole.passenger;
  }
}

class AuthSession {
  AuthSession({required this.userId, required String role}) : role = userRoleFromString(role);

  final String userId;
  final UserRole role;
}
