import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Thin wrapper around flutter_secure_storage that never throws.
///
/// On Flutter web, flutter_secure_storage uses the browser's Web Crypto API
/// and IndexedDB. Both can throw OperationError (typically from stale/
/// corrupted key material in IndexedDB left by a previous run) or fail
/// silently in some browser configurations. We treat any storage failure
/// as "no session stored" and fall through to the login screen rather
/// than crashing the app.
class TokenStorage {
  const TokenStorage();

  // WebOptions sets the IndexedDB database name and the AES key label.
  // Keeping these explicit prevents accidental cross-app key collisions
  // when multiple Flutter web apps run on the same localhost origin.
  static const _storage = FlutterSecureStorage(
    webOptions: WebOptions(
      dbName: 'otuuse_transport',
      publicKey: 'otuuse_transport_key',
    ),
  );

  static const _accessKey = 'access_token';
  static const _refreshKey = 'refresh_token';
  static const _userIdKey = 'user_id';
  static const _userRoleKey = 'user_role';

  Future<String?> getAccessToken() async {
    try {
      return await _storage.read(key: _accessKey);
    } catch (_) {
      return null;
    }
  }

  Future<String?> getRefreshToken() async {
    try {
      return await _storage.read(key: _refreshKey);
    } catch (_) {
      return null;
    }
  }

  Future<String?> getUserId() async {
    try {
      return await _storage.read(key: _userIdKey);
    } catch (_) {
      return null;
    }
  }

  Future<String?> getUserRole() async {
    try {
      return await _storage.read(key: _userRoleKey);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
    required String userId,
    required String userRole,
  }) async {
    try {
      await Future.wait([
        _storage.write(key: _accessKey, value: accessToken),
        _storage.write(key: _refreshKey, value: refreshToken),
        _storage.write(key: _userIdKey, value: userId),
        _storage.write(key: _userRoleKey, value: userRole),
      ]);
    } catch (_) {
      // On web, a write failure means the session won't persist across
      // page reloads, but the current session continues working fine.
    }
  }

  Future<void> clearTokens() async {
    try {
      await _storage.deleteAll();
    } catch (_) {}
  }
}
