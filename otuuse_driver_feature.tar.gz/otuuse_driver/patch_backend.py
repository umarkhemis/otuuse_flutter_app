"""
Run this from ~/otuuse/kabale_transport with the venv active:
    python3 patch_backend.py
"""
path = 'app/api/routes/routes.py'
with open(path) as f:
    content = f.read()

old = '''@driver_router.post("/documents")
async def upload_driver_document('''

new = '''@driver_router.get("/ride/active")
async def get_driver_active_ride(
    current_user: Annotated[User, Depends(get_current_driver)],
    db: AsyncSession = Depends(get_db),
):
    """
    Polling endpoint called every 4 seconds by the driver app.
    Returns the driver\'s current active ride (any status from MATCHED
    through IN_PROGRESS), or null if none. Used in place of FCM push
    notifications during development.
    """
    from app.services.crud import get_active_ride_for_driver
    ride = await get_active_ride_for_driver(user_id=current_user.id, db=db)
    if not ride:
        return {"ride": None}
    passenger = await db.get(User, ride.passenger_id)
    return {
        "ride": {
            "id": str(ride.id),
            "status": ride.status.value,
            "pickup_name": ride.pickup_name,
            "dropoff_name": ride.dropoff_name,
            "estimated_fare_ugx": ride.estimated_fare_ugx,
            "estimated_distance_km": ride.estimated_distance_km,
            "estimated_duration_minutes": ride.estimated_duration_minutes,
            "passenger_name": passenger.name if passenger else "Passenger",
        }
    }


@driver_router.post("/documents")
async def upload_driver_document('''

if old in content:
    content = content.replace(old, new)
    with open(path, 'w') as f:
        f.write(content)
    print("Done - GET /driver/ride/active added")
else:
    print("ERROR: anchor text not found in routes.py")
