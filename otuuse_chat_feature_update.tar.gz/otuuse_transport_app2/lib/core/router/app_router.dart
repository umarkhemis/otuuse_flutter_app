import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/data/auth_session.dart';
import '../../features/auth/providers/auth_provider.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/otp_screen.dart';
import '../../features/chat/screens/chat_screen.dart';
import '../../features/driver/screens/driver_home_screen.dart';
import 'splash_screen.dart';

/// go_router needs a plain Listenable to know when to re-run its redirect
/// logic. Riverpod's StateNotifierProvider isn't one directly, so this
/// small bridge listens for auth state changes and notifies go_router when
/// they happen.
class _RouterRefreshNotifier extends ChangeNotifier {
  _RouterRefreshNotifier(Ref ref) {
    ref.listen(authProvider, (_, __) => notifyListeners());
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final refreshNotifier = _RouterRefreshNotifier(ref);

  return GoRouter(
    initialLocation: '/',
    refreshListenable: refreshNotifier,
    redirect: (context, state) {
      final authState = ref.read(authProvider);
      final isAuthRoute = state.matchedLocation == '/login' || state.matchedLocation == '/verify-otp';

      // Still checking secure storage for a saved session - stay on splash.
      if (authState.status == AuthStatus.unknown) {
        return state.matchedLocation == '/' ? null : '/';
      }

      if (authState.status == AuthStatus.unauthenticated) {
        return isAuthRoute ? null : '/login';
      }

      // Authenticated: always land on the home screen for their role -
      // covers splash/login/OTP, and also guards against ending up on the
      // wrong-role home screen (e.g. a passenger somehow at /driver/home).
      if (authState.status == AuthStatus.authenticated) {
        final correctHome = authState.session?.role == UserRole.driver ? '/driver/home' : '/rides/home';
        if (state.matchedLocation != correctHome) {
          return correctHome;
        }
      }

      return null;
    },
    routes: [
      GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/verify-otp',
        builder: (context, state) {
          final phoneNumber = state.extra as String?;
          if (phoneNumber == null) {
            // Can happen on web after a page refresh - extra data doesn't
            // survive that, since it only ever lived in memory. Bounce back
            // to login rather than crash on a bad cast.
            return const LoginScreen();
          }
          return OtpScreen(phoneNumber: phoneNumber);
        },
      ),
      GoRoute(path: '/rides/home', builder: (context, state) => const ChatScreen()),
      GoRoute(path: '/driver/home', builder: (context, state) => const DriverHomeScreen()),
    ],
  );
});
