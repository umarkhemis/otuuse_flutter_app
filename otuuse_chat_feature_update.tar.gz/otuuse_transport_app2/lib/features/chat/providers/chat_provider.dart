import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/providers/auth_provider.dart';
import '../data/chat_models.dart';
import '../data/chat_repository.dart';

class ChatState {
  const ChatState({
    this.turns = const [],
    this.isSending = false,
    this.errorMessage,
  });

  final List<ChatTurn> turns;
  final bool isSending;
  final String? errorMessage;

  ChatState copyWith({
    List<ChatTurn>? turns,
    bool? isSending,
    String? errorMessage,
  }) {
    return ChatState(
      turns: turns ?? this.turns,
      isSending: isSending ?? this.isSending,
      // Explicitly nullable - copyWith(errorMessage: null) needs to actually
      // clear it, not fall back to the old value like the other fields do.
      errorMessage: errorMessage,
    );
  }
}

class ChatNotifier extends Notifier<ChatState> {
  @override
  ChatState build() {
    return const ChatState(
      turns: [
        ChatTurn(
          role: ChatTurnRole.agent,
          text: 'Hi! Where would you like to go, or what would you like delivered?',
        ),
      ],
    );
  }

  Future<void> sendMessage(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || state.isSending) return;

    state = state.copyWith(
      turns: [...state.turns, ChatTurn(role: ChatTurnRole.user, text: trimmed)],
      isSending: true,
      errorMessage: null,
    );

    try {
      final repository = ref.read(chatRepositoryProvider);
      final response = await repository.sendMessage(trimmed);

      state = state.copyWith(
        turns: [
          ...state.turns,
          ChatTurn(
            role: ChatTurnRole.agent,
            text: response.reply,
            fareUgx: response.fareUgx,
            fareStatus: response.fareUgx != null ? FareQuoteStatus.pending : null,
          ),
        ],
        isSending: false,
      );
    } catch (e) {
      state = state.copyWith(isSending: false, errorMessage: e.toString());
    }
  }

  /// [turnIndex] identifies which fare-quote card the passenger responded
  /// to, so we can flip just that card to confirmed/cancelled rather than
  /// guessing which one is "the current" quote.
  Future<void> respondToFareQuote(int turnIndex, bool confirmed) async {
    if (state.isSending) return;

    state = state.copyWith(isSending: true, errorMessage: null);

    try {
      final repository = ref.read(chatRepositoryProvider);
      final result = await repository.confirmRide(confirmed);

      final updatedTurns = [...state.turns];
      updatedTurns[turnIndex] = updatedTurns[turnIndex].copyWith(
        fareStatus: confirmed ? FareQuoteStatus.confirmed : FareQuoteStatus.cancelled,
      );
      updatedTurns.add(ChatTurn(role: ChatTurnRole.agent, text: result.message));

      state = state.copyWith(turns: updatedTurns, isSending: false);
    } catch (e) {
      state = state.copyWith(isSending: false, errorMessage: e.toString());
    }
  }
}

final chatRepositoryProvider = Provider<ChatRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return ChatRepository(apiClient);
});

final chatProvider = NotifierProvider<ChatNotifier, ChatState>(ChatNotifier.new);
