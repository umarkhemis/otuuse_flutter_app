import 'package:dio/dio.dart';

import '../../../core/api/api_client.dart';
import '../../../core/api/api_exception.dart';
import 'chat_models.dart';

class ChatRepository {
  ChatRepository(this._apiClient);

  final ApiClient _apiClient;

  Future<ChatApiResponse> sendMessage(String message) async {
    try {
      final response = await _apiClient.dio.post('/chat/message', data: {
        'message': message,
      });
      return ChatApiResponse.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw ApiException.fromDioException(e);
    }
  }

  /// [confirmed] = true creates the ride and triggers dispatch server-side.
  /// false discards whatever fare quote is currently pending in Redis.
  Future<ConfirmRideResult> confirmRide(bool confirmed) async {
    try {
      final response = await _apiClient.dio.post('/chat/confirm-ride', data: {
        'confirmed': confirmed,
      });
      final data = response.data as Map<String, dynamic>;
      return ConfirmRideResult(
        rideId: data['ride_id'] as String?,
        message: data['message'] as String,
      );
    } on DioException catch (e) {
      throw ApiException.fromDioException(e);
    }
  }
}
