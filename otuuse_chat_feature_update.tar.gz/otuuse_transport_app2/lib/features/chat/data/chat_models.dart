/// Mirrors the backend's ChatResponse (app/api/routes/routes.py).
class ChatApiResponse {
  ChatApiResponse({
    required this.reply,
    required this.intent,
    this.rideId,
    this.deliveryId,
    this.fareUgx,
  });

  final String reply;
  final String intent;
  final String? rideId;
  final String? deliveryId;
  final int? fareUgx;

  factory ChatApiResponse.fromJson(Map<String, dynamic> json) {
    return ChatApiResponse(
      reply: json['reply'] as String,
      intent: json['intent'] as String,
      rideId: json['ride_id'] as String?,
      deliveryId: json['delivery_id'] as String?,
      fareUgx: json['fare_ugx'] as int?,
    );
  }
}

/// Result of POST /chat/confirm-ride. rideId is null if the passenger
/// cancelled - check message either way, since a ride can also be created
/// with no driver currently available.
class ConfirmRideResult {
  ConfirmRideResult({this.rideId, required this.message});

  final String? rideId;
  final String message;
}

enum ChatTurnRole { user, agent }

enum FareQuoteStatus { pending, confirmed, cancelled }

/// A single bubble in the conversation. fareUgx/fareStatus are only set on
/// agent turns that came with a fare quote attached.
class ChatTurn {
  const ChatTurn({
    required this.role,
    required this.text,
    this.fareUgx,
    this.fareStatus,
  });

  final ChatTurnRole role;
  final String text;
  final int? fareUgx;
  final FareQuoteStatus? fareStatus;

  ChatTurn copyWith({FareQuoteStatus? fareStatus}) {
    return ChatTurn(
      role: role,
      text: text,
      fareUgx: fareUgx,
      fareStatus: fareStatus ?? this.fareStatus,
    );
  }
}
